local _, addon = ...

addon.huokanMailRecipients = {
	["Illidan"] = "Oppyspark",
}
