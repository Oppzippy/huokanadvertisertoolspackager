# Huokan Advertiser Tools

## [v1.0.0](https://github.com/Oppzippy/HuokanAdvertiserTools/tree/v1.0.0) (2021-06-05)
[Full Changelog](https://github.com/Oppzippy/HuokanAdvertiserTools/compare/v0.1.0...v1.0.0) [Previous Releases](https://github.com/Oppzippy/HuokanAdvertiserTools/releases)

- Add AceComm-3.0 dependency  
- Only show guild bank deposits in Huokan guilds  
- Add version check  
- Add placeholder discord tag  
- Add slash command for guild bank ui  
- Store deposits globally  
- Add notes  
- Add locales  
- Remove discord name  
- Add TODO  
- Add guild bank module  
- Remove unused file  
- Adjust naming  
- Provide compressed deposit info export  
- Remove payment module, add guild deposit module  
- Auto hide payment frame  
- Revert "Add CHANGELOG to pkgmeta ignore"  
- Add CHANGELOG to pkgmeta ignore  
