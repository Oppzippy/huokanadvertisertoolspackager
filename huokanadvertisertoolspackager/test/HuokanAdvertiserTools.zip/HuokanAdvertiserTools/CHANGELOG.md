# Huokan Advertiser Tools

## [v0.1.0](https://github.com/Oppzippy/HuokanAdvertiserTools/tree/v0.1.0) (2020-08-18)
[Full Changelog](https://github.com/Oppzippy/HuokanAdvertiserTools/commits/v0.1.0) [Previous Releases](https://github.com/Oppzippy/HuokanAdvertiserTools/releases)

- Add timezone to verification text  
- Add Custom.lua for the python script to modify  
- Use discord names instead of tags  
- Use default github token  
- Adjust mail subject format  
- Fix addon name  
- Put discord tag in subject instead of body  
- Fix addon name  
- Create README.md  
- Remove unused library  
- Initial commit  
