local L = LibStub("AceLocale-3.0"):NewLocale("HuokanPayout", "ptBR")
if not L then return end
