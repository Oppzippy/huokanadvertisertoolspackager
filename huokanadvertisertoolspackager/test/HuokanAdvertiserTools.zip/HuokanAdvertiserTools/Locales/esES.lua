local L = LibStub("AceLocale-3.0"):NewLocale("HuokanPayout", "esES") or LibStub("AceLocale-3.0"):NewLocale("HuokanPayout", "esMX")
if not L then return end
